use increpastour;

drop table noticeBoard;

create table noticeBoard(
	n_board_idx int auto_increment, 
    n_board_title varchar(100) not null,
    n_board_contents longtext not null,
    n_board_regDate datetime not null,
    n_board_views int,
    n_board_file varchar(300),
    n_board_writer varchar(100),
    constraint n_board_idx_PK primary key(n_board_idx)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

commit;

select * from noticeBoard
order by n_board_idx desc;

INSERT INTO noticeBoard(n_board_title, n_board_contents, n_board_regDate, n_board_views, n_board_writer)
		VALUES('title', '본문', now(),0, '관리자');

delete from noticeBoard where n_board_idx = 4;

select * from noticeBoard;

delete from noticeBoard where n_board_idx = 10;

update noticeBoard 
set n_board_title = '1', n_board_contents = '123123123', n_board_file = ''
where n_board_idx = 1;
