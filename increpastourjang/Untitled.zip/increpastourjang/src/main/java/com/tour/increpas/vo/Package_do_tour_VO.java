package com.tour.increpas.vo;

public class Package_do_tour_VO {

	private int package_do_tour_idx; // 일련번호
	private int package_do_tour_total; // 패키지 일수
	private int package_do_tour_price; // 패키지 총액
	private int package_do_tour_seatno; // 좌석넘버

	private String package_do_tour_name; // 패키지 이름
	private String package_do_tour_start_date; // 출발날짜
	private String package_do_tour_end_date; // 도착날짜
	private String package_do_tour_image;// 여행 사진 상세
	private String package_do_tour_thumbnail;// 패키지 여행 썸네일
	private String package_do_tour_contents; // 패키지여행 설명란
	private String package_do_tour_start; // 출발 도시
	private String package_do_tour_arrive;// 도착 도시
	private String package_do_tour_bus; // 버스여부
	private String package_do_tour_busclass; // 버스 크기
	private String package_do_tour_air; // 비행기여부
	private String package_do_tour_airclass; // 비행기 클라스
	private String package_do_tour_hotel_class;// 호텔클라스
	private String package_do_tour_busagency;// 버스 회사
	private String package_do_tour_airagency;// 비행기 회사
	private String package_do_tour_theme;// 테마여행
	private String package_do_tour_status;// 현재상태 : 예메가능; 예매불가
	private String package_do_tour_free; // 자유일정가능
	private String package_do_tour_shopping;// 쇼핑가능
	private String package_do_tour_manager;// 담당 매니저

	// 지도 위도 경도
	private int idx;
	private String area;
	private double location_lat;
	private double location_lng;

	// 기본생성자
	public Package_do_tour_VO() {
	}

	// 패키지 리스트
	public Package_do_tour_VO(int package_do_tour_idx, int package_do_tour_total, int package_do_tour_price,
			int package_do_tour_seatno, String package_do_tour_name, String package_do_tour_start_date,
			String package_do_tour_end_date, String package_do_tour_image, String package_do_tour_thumbnail,
			String package_do_tour_contents, String package_do_tour_start, String package_do_tour_arrive,
			String package_do_tour_bus, String package_do_tour_busclass, String package_do_tour_air,
			String package_do_tour_airclass, String package_do_tour_hotel_class, String package_do_tour_busagency,
			String package_do_tour_airagency, String package_do_tour_theme, String package_do_tour_status,
			String package_do_tour_free, String package_do_tour_shopping, String package_do_tour_manager) {
		super();
		this.package_do_tour_idx = package_do_tour_idx;
		this.package_do_tour_total = package_do_tour_total;
		this.package_do_tour_price = package_do_tour_price;
		this.package_do_tour_seatno = package_do_tour_seatno;
		this.package_do_tour_name = package_do_tour_name;
		this.package_do_tour_start_date = package_do_tour_start_date;
		this.package_do_tour_end_date = package_do_tour_end_date;
		this.package_do_tour_image = package_do_tour_image;
		this.package_do_tour_thumbnail = package_do_tour_thumbnail;
		this.package_do_tour_contents = package_do_tour_contents;
		this.package_do_tour_start = package_do_tour_start;
		this.package_do_tour_arrive = package_do_tour_arrive;
		this.package_do_tour_bus = package_do_tour_bus;
		this.package_do_tour_busclass = package_do_tour_busclass;
		this.package_do_tour_air = package_do_tour_air;
		this.package_do_tour_airclass = package_do_tour_airclass;
		this.package_do_tour_hotel_class = package_do_tour_hotel_class;
		this.package_do_tour_busagency = package_do_tour_busagency;
		this.package_do_tour_airagency = package_do_tour_airagency;
		this.package_do_tour_theme = package_do_tour_theme;
		this.package_do_tour_status = package_do_tour_status;
		this.package_do_tour_free = package_do_tour_free;
		this.package_do_tour_shopping = package_do_tour_shopping;
		this.package_do_tour_manager = package_do_tour_manager;

	}

	// 맵 위도경도 리스트 뽑아내기
	public Package_do_tour_VO(int idx, String area, float location_lat, float location_lng) {
		super();
		this.idx = idx;
		this.area = area;
		this.location_lat = location_lat;
		this.location_lng = location_lng;

	}

	// 맵 getter setter
	public int getIdx() {
		return idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public double getLocation_lat() {
		return location_lat;
	}

	public void setLocation_lat(double location_lat) {
		this.location_lat = location_lat;
	}

	public double getLocation_lng() {
		return location_lng;
	}
	// 맵 getter setter

	public void setLocation_lng(double location_lng) {
		this.location_lng = location_lng;
	}

	public int getPackage_do_tour_idx() {
		return package_do_tour_idx;
	}

	public void setPackage_do_tour_idx(int package_do_tour_idx) {
		this.package_do_tour_idx = package_do_tour_idx;
	}

	public int getPackage_do_tour_total() {
		return package_do_tour_total;
	}

	public void setPackage_do_tour_total(int package_do_tour_total) {
		this.package_do_tour_total = package_do_tour_total;
	}

	public int getPackage_do_tour_price() {
		return package_do_tour_price;
	}

	public void setPackage_do_tour_price(int package_do_tour_price) {
		this.package_do_tour_price = package_do_tour_price;
	}

	public int getPackage_do_tour_seatno() {
		return package_do_tour_seatno;
	}

	public void setPackage_do_tour_seatno(int package_do_tour_seatno) {
		this.package_do_tour_seatno = package_do_tour_seatno;
	}

	public String getPackage_do_tour_name() {
		return package_do_tour_name;
	}

	public void setPackage_do_tour_name(String package_do_tour_name) {
		this.package_do_tour_name = package_do_tour_name;
	}

	public String getPackage_do_tour_start_date() {
		return package_do_tour_start_date;
	}

	public void setPackage_do_tour_start_date(String package_do_tour_start_date) {
		this.package_do_tour_start_date = package_do_tour_start_date;
	}

	public String getPackage_do_tour_end_date() {
		return package_do_tour_end_date;
	}

	public void setPackage_do_tour_end_date(String package_do_tour_end_date) {
		this.package_do_tour_end_date = package_do_tour_end_date;
	}

	public String getPackage_do_tour_image() {
		return package_do_tour_image;
	}

	public void setPackage_do_tour_image(String package_do_tour_image) {
		this.package_do_tour_image = package_do_tour_image;
	}

	public String getPackage_do_tour_thumbnail() {
		return package_do_tour_thumbnail;
	}

	public void setPackage_do_tour_thumbnail(String package_do_tour_thumbnail) {
		this.package_do_tour_thumbnail = package_do_tour_thumbnail;
	}

	public String getPackage_do_tour_contents() {
		return package_do_tour_contents;
	}

	public void setPackage_do_tour_contents(String package_do_tour_contents) {
		this.package_do_tour_contents = package_do_tour_contents;
	}

	public String getPackage_do_tour_start() {
		return package_do_tour_start;
	}

	public void setPackage_do_tour_start(String package_do_tour_start) {
		this.package_do_tour_start = package_do_tour_start;
	}

	public String getPackage_do_tour_arrive() {
		return package_do_tour_arrive;
	}

	public void setPackage_do_tour_arrive(String package_do_tour_arrive) {
		this.package_do_tour_arrive = package_do_tour_arrive;
	}

	public String getPackage_do_tour_bus() {
		return package_do_tour_bus;
	}

	public void setPackage_do_tour_bus(String package_do_tour_bus) {
		this.package_do_tour_bus = package_do_tour_bus;
	}

	public String getPackage_do_tour_busclass() {
		return package_do_tour_busclass;
	}

	public void setPackage_do_tour_busclass(String package_do_tour_busclass) {
		this.package_do_tour_busclass = package_do_tour_busclass;
	}

	public String getPackage_do_tour_air() {
		return package_do_tour_air;
	}

	public void setPackage_do_tour_air(String package_do_tour_air) {
		this.package_do_tour_air = package_do_tour_air;
	}

	public String getPackage_do_tour_airclass() {
		return package_do_tour_airclass;
	}

	public void setPackage_do_tour_airclass(String package_do_tour_airclass) {
		this.package_do_tour_airclass = package_do_tour_airclass;
	}

	public String getPackage_do_tour_hotel_class() {
		return package_do_tour_hotel_class;
	}

	public void setPackage_do_tour_hotel_class(String package_do_tour_hotel_class) {
		this.package_do_tour_hotel_class = package_do_tour_hotel_class;
	}

	public String getPackage_do_tour_busagency() {
		return package_do_tour_busagency;
	}

	public void setPackage_do_tour_busagency(String package_do_tour_busagency) {
		this.package_do_tour_busagency = package_do_tour_busagency;
	}

	public String getPackage_do_tour_airagency() {
		return package_do_tour_airagency;
	}

	public void setPackage_do_tour_airagency(String package_do_tour_airagency) {
		this.package_do_tour_airagency = package_do_tour_airagency;
	}

	public String getPackage_do_tour_theme() {
		return package_do_tour_theme;
	}

	public void setPackage_do_tour_theme(String package_do_tour_theme) {
		this.package_do_tour_theme = package_do_tour_theme;
	}

	public String getPackage_do_tour_status() {
		return package_do_tour_status;
	}

	public void setPackage_do_tour_status(String package_do_tour_status) {
		this.package_do_tour_status = package_do_tour_status;
	}

	public String getPackage_do_tour_free() {
		return package_do_tour_free;
	}

	public void setPackage_do_tour_free(String package_do_tour_free) {
		this.package_do_tour_free = package_do_tour_free;
	}

	public String getPackage_do_tour_shopping() {
		return package_do_tour_shopping;
	}

	public void setPackage_do_tour_shopping(String package_do_tour_shopping) {
		this.package_do_tour_shopping = package_do_tour_shopping;
	}

	public String getPackage_do_tour_manager() {
		return package_do_tour_manager;
	}

	public void setPackage_do_tour_manager(String package_do_tour_manager) {
		this.package_do_tour_manager = package_do_tour_manager;
	}
}