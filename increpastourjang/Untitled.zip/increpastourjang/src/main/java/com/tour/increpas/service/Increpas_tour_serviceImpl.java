package com.tour.increpas.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tour.increpas.dao.IncrepasTourDaoImpl;
import com.tour.increpas.vo.NoticeBoardVO;
import com.tour.increpas.vo.Package_do_tour_VO;
import com.tour.increpas.vo.Package_tour_VO;

@Service
public class Increpas_tour_serviceImpl implements IncrepasTourService {

	private static final int PAGE_SIZE = 10;
	private static final int PAGE_GROUP = 10;

	@Autowired
	private IncrepasTourDaoImpl increpasTourDaoImpl;

	public void setIncdao(IncrepasTourDaoImpl increpasTourDaoImpl) {
		this.increpasTourDaoImpl = increpasTourDaoImpl;
	}

	@Override
	public List<Package_do_tour_VO> package_do_List() {
		// 국내 관련
		return increpasTourDaoImpl.package_do_List();
	}

	@Override
	public Package_do_tour_VO getBoard(int package_do_tour_idx) {
		// 국내 관련 상세보기
		return increpasTourDaoImpl.getBoard(package_do_tour_idx);
	}

	// 맵관련
	public List<Package_do_tour_VO> map_List() {
		return increpasTourDaoImpl.map_List();
	}

	@Override
	public Package_tour_VO overSeaPackageDetail(int package_tour_idx) {
		// TODO Auto-generated method stub
		return increpasTourDaoImpl.overSeaPackageDetail(package_tour_idx);
	}

	@Override
	public void insertNoticeBoard(NoticeBoardVO noticeBoardVO) {
		// TODO Auto-generated method stub
		increpasTourDaoImpl.insertNoticeBoard(noticeBoardVO);
	}

	@Override
	public void deleteNoticeBoard(int n_board_idx) {
		// TODO Auto-generated method stub
		increpasTourDaoImpl.deleteNoticeBoard(n_board_idx);
	}

	@Override
	public NoticeBoardVO noticeBoardDetail(int n_board_idx) {
		// TODO Auto-generated method stub
		return increpasTourDaoImpl.noticeBoardDetail(n_board_idx);
	}

	@Override
	public int getNoticeBoardCount(String category, String keyword) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Map<String, Object> noticeBoardList(int pageNum, String category, String keyword) {
		// TODO Auto-generated method stub
		int currentPage = pageNum;
		int startRow = (currentPage - 1) * PAGE_SIZE;
		int listCount = 0;
		boolean searchOption = (category.equals("null") || keyword.equals("null")) ? false : true;
		listCount = increpasTourDaoImpl.getNoticeBoardCount(category, keyword);
		if (listCount > 0) {
			List<NoticeBoardVO> noticeBoardList = increpasTourDaoImpl.noticeBoardList(startRow, PAGE_SIZE, category,
					keyword);
			int pageCount = listCount / PAGE_SIZE + (listCount % PAGE_SIZE == 0 ? 0 : 1);
			int startPage = (currentPage / PAGE_GROUP) * PAGE_GROUP + 1
					- (currentPage % PAGE_GROUP == 0 ? PAGE_GROUP : 0);
			int endPage = startPage + PAGE_GROUP - 1;

			if (endPage > pageCount) {
				endPage = pageCount;
			}

			Map<String, Object> modelMap = new HashMap<String, Object>();
			modelMap.put("noticeBoardList", noticeBoardList);
			modelMap.put("pageCount", pageCount);
			modelMap.put("startPage", startPage);
			modelMap.put("endPage", endPage);
			modelMap.put("currentPage", currentPage);
			modelMap.put("listCount", listCount);
			modelMap.put("pageGroup", PAGE_GROUP);
			modelMap.put("searchOption", searchOption);
			// System.out.println("noticeBoardList:" + noticeBoardList.size());

			if (searchOption) {
				try {
					modelMap.put("keyword", URLEncoder.encode(keyword, "utf-8"));
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
				modelMap.put("word", keyword);
				modelMap.put("category", category);
			}
			return modelMap;
		} else {
			return null;
		}
	}

	@Override
	public Map<String, Object> packageList(String nations, String category, String keyword) {
		// TODO Auto-generated method stub
		boolean searchOption = (nations.equals("null") || category.equals("null") || keyword.equals("null")) ? false
				: true;
		List<Package_tour_VO> packageList = increpasTourDaoImpl.packageList(nations, category, keyword);

		Map<String, Object> modelMap = new HashMap<String, Object>();
		modelMap.put("searchOption", searchOption);
		System.out.println("searchOption : " + searchOption);

		if (searchOption) {
			try {
				modelMap.put("nations", URLEncoder.encode(nations, "utf-8"));
				modelMap.put("category", URLEncoder.encode(category, "utf-8"));
				modelMap.put("keyword", URLEncoder.encode(keyword, "utf-8"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			modelMap.put("packageList", packageList);
			modelMap.put("nations", nations);
			modelMap.put("word", keyword);
			modelMap.put("category", category);
			System.out.println(modelMap);
			System.out.println("packageList :" + packageList.size());
			return modelMap;
		} else {
			modelMap.put("packageList", packageList);
			return modelMap;
		}
	}

	@Override
	public void insertPackageList(Package_tour_VO package_tour_vo) {
		// TODO Auto-generated method stub
		increpasTourDaoImpl.insertPackageList(package_tour_vo);
	}

	@Override
	public void deletePackageList(int package_tour_idx) {
		// TODO Auto-generated method stub
		increpasTourDaoImpl.deletePackageList(package_tour_idx);
	}

	@Override
	public void updateNoticeBoard(NoticeBoardVO noticeBoardVO) {
		// TODO Auto-generated method stub
		System.out.println("updateNoticeBoard");
		increpasTourDaoImpl.updateNoticeBoard(noticeBoardVO);
	}

	@Override
	public void updatePackageList(Package_tour_VO package_tour_VO) {
		// TODO Auto-generated method stub
		System.out.println("updatePackageList");
		increpasTourDaoImpl.updatePackageList(package_tour_VO);
	}
}