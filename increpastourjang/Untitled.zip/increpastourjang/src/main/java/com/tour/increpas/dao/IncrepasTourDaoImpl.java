package com.tour.increpas.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tour.increpas.vo.NoticeBoardVO;
import com.tour.increpas.vo.Package_do_tour_VO;
import com.tour.increpas.vo.Package_tour_VO;

@Repository
public class IncrepasTourDaoImpl implements IncrepasTourDao {

	private final String NAME_SPACE = "com.tour.increpas.package.tour.mapper";

	private SqlSessionTemplate sqlSession;

	@Autowired
	public void setSqlSession(SqlSessionTemplate sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public List<Package_do_tour_VO> package_do_List() {
		// 국내여행 관련
		return sqlSession.selectList(NAME_SPACE + ".package_do_List");
	}

	@Override
	public Package_do_tour_VO getBoard(int package_do_tour_idx) {

		return sqlSession.selectOne(NAME_SPACE + ".getBoard", package_do_tour_idx);
	}

	// 맵 관련
	@Override
	public List<Package_do_tour_VO> map_List() {
		return sqlSession.selectList(NAME_SPACE + ".map_List");
	}

	@Override
	public Package_tour_VO overSeaPackageDetail(int package_tour_idx) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne(NAME_SPACE + ".overSeaPackageDetail", package_tour_idx);
	}

	@Override
	public List<NoticeBoardVO> noticeBoardList(int startRow, int num, String category, String keyword) {
		// TODO Auto-generated method stub
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("startRow", startRow);
		params.put("num", num);
		params.put("category", category);
		params.put("keyword", keyword);
		return sqlSession.selectList(NAME_SPACE + ".noticeBoardList", params);
	}

	@Override
	public void insertNoticeBoard(NoticeBoardVO noticeBoardVO) {
		// TODO Auto-generated method stub
		sqlSession.insert(NAME_SPACE + ".insertNoticeBoard", noticeBoardVO);
	}

	@Override
	public void deleteNoticeBoard(int n_board_idx) {
		// TODO Auto-generated method stub
		System.out.println("삭제 idx = " + n_board_idx);
		sqlSession.delete(NAME_SPACE + ".deleteNoticeBoard", n_board_idx);
	}

	@Override
	public NoticeBoardVO noticeBoardDetail(int n_board_idx) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne(NAME_SPACE + ".noticeBoardDetail", n_board_idx);
	}

	@Override
	public int getNoticeBoardCount(String category, String keyword) {
		// TODO Auto-generated method stub
		Map<String, String> params = new HashMap<String, String>();
		params.put("category", category);
		params.put("keyword", keyword);
		return sqlSession.selectOne(NAME_SPACE + ".getNoticeBoardCount", params);
	}

	@Override
	public List<Package_tour_VO> packageList(String nations, String category, String keyword) {
		// TODO Auto-generated method stub
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("nations", nations);
		params.put("category", category);
		params.put("keyword", keyword);
		return sqlSession.selectList(NAME_SPACE + ".packageList", params);
	}

	@Override
	public void insertPackageList(Package_tour_VO package_tour_vo) {
		// TODO Auto-generated method stub
		sqlSession.insert(NAME_SPACE + ".insertPackageList", package_tour_vo);
	}

	@Override
	public void deletePackageList(int package_tour_idx) {
		// TODO Auto-generated method stub
		sqlSession.delete(NAME_SPACE + ".deletePackageList", package_tour_idx);
	}

	@Override
	public void updateNoticeBoard(NoticeBoardVO noticeBoardVO) {
		// TODO Auto-generated method stub
		System.out.println(".updateNoticeBoard");
		sqlSession.update(NAME_SPACE + ".updateNoticeBoard", noticeBoardVO);
	}

	@Override
	public void updatePackageList(Package_tour_VO package_tour_VO) {
		// TODO Auto-generated method stub
		System.out.println(".updatePackageList");
		sqlSession.update(NAME_SPACE + ".updatePackageList", package_tour_VO);
	}
}