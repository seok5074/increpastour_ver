package com.tour.increpas.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tour.increpas.service.IncrepasTourService;

@Controller
public class TabMenuController {

	

	@RequestMapping("/activetab")
	public String bodyTabMenu(Model model, 
			@RequestParam(value="tab", defaultValue="tab01") String tab) {
		
				
		return tab;
	}
	
	
	/* 키워드 랭킹 검색창 아래있는 실시간 점멸되는 그거입니다 아직미완성 서비스랑 dao sql문 db관련 어떻게해야할지고민후 
	 * 진행!! */
	/*
	 * @RequestMapping("/searchRank") public String searchRank(Model model ) {
	 * 
	 * return IncrepasTourService.rankKeyword(); }
	 */	
	
	
}
