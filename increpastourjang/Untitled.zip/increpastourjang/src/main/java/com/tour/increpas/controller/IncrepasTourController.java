package com.tour.increpas.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.tour.increpas.service.IncrepasTourService;
import com.tour.increpas.vo.NoticeBoardVO;
import com.tour.increpas.vo.Package_do_tour_VO;
import com.tour.increpas.vo.Package_tour_VO;

@Controller
public class IncrepasTourController {

	private IncrepasTourService increpasTourService;
	private final static String DEFAULT_PATH = "/resources/upload/"; // 게시판 업로드 경로
	private final static String IMAGE_PATH = "/resources/images/"; // 패키지 이미지 업로드 경로

	@Autowired
	public void setIncService(IncrepasTourService increpasTourService) {
		this.increpasTourService = increpasTourService;
	}

	// 스타트 페이지
	@RequestMapping(value = { "/", "/start" }, method = RequestMethod.GET)
	public String index(Model model) {

		return "startPage";
	}

	// 메인 첫페이지
	@RequestMapping(value = { "/main" }, method = RequestMethod.GET)
	public String index1(Model model) {

		return "main";
	}

	// 해외 리스트
	@RequestMapping(value = { "/packageList", "/list" }, method = RequestMethod.GET)
	public String packageList(Model model,
			@RequestParam(value = "nations", required = false, defaultValue = "null") String nations,
			@RequestParam(value = "category", required = false, defaultValue = "null") String category,
			@RequestParam(value = "keyword", required = false, defaultValue = "null") String keyword) {
		Map<String, Object> modelMap = increpasTourService.packageList(nations, category, keyword);
		model.addAllAttributes(modelMap);
		return "oversea/packageList";
	}

	// 국내 메인
	@RequestMapping(value = { "/domestcpackage" }, method = RequestMethod.GET)
	public String index8(Model model) {
		List<Package_do_tour_VO> package_do_List = increpasTourService.package_do_List();
		List<Package_do_tour_VO> map_List = increpasTourService.map_List();

		model.addAttribute("package_do_List", package_do_List);
		model.addAttribute("map_List", map_List);

		/*
		 * // 자바스크립트에서 데이터에 접근하려면 ? -> 텍스트 아님 JSON ObjectMapper mapper = new
		 * ObjectMapper(); String jsonStr = mapper.writeValueAsString(list);
		 * 
		 * model.addAttribute("jsonStr",jsonStr);
		 */

		return "domesticmain";
	}

	// 국내관련
	// 국내 여행 패키지 리스트 국내 패키지 전체 리스트
	@RequestMapping(value = { "/packagedoList", "/dolist" }, method = RequestMethod.GET)
	public String package_do_List(Model model) {
		List<Package_do_tour_VO> package_do_List = increpasTourService.package_do_List();
		model.addAttribute("package_do_List", package_do_List);
		return "domestcpackage/packagedoList";
	}

	// 국내패키지 메인
	@RequestMapping(value = { "/packagemain" }, method = RequestMethod.GET)
	public String index3(Model model) {
		List<Package_do_tour_VO> package_do_List = increpasTourService.package_do_List();
		model.addAttribute("package_do_List", package_do_List);
		return "domestcpackage/packagedo";
	}

	// 국내패키지 상세보기
	@RequestMapping("/packagedodetail")
	public String package_do_detail(Model model,
			@RequestParam(value = "no", required = false) int package_do_tour_idx) {

		Package_do_tour_VO package_do_tour_VO = increpasTourService.getBoard(package_do_tour_idx);

		model.addAttribute("package_do_tour_VO", package_do_tour_VO);
		List<Package_do_tour_VO> package_do_List = increpasTourService.package_do_List();
		model.addAttribute("package_do_List", package_do_List);
		return "domestcpackage/packagedodetail";
	}

	// 이벤트 게임 메인페이지
	@RequestMapping(value = { "/eventpage" }, method = RequestMethod.GET)
	public String index4(Model model) {

		return "eventpage/mainevent";
	}

	// 이벤트 토토페이지
	@RequestMapping(value = { "/totopage" }, method = RequestMethod.GET)
	public String index5(Model model) {

		return "eventpage/totopage";
	}

	// 이벤트 야바위 페이지
	@RequestMapping(value = { "/yabawipage" }, method = RequestMethod.GET)
	public String index6(Model model) {

		return "eventpage/yabawipage";
	}

	// 이벤트 룰렛 페이지
	@RequestMapping(value = { "/roulettepage" }, method = RequestMethod.GET)
	public String index7(Model model) {

		return "eventpage/roulettepage";
	}

	// 공지사항 게시판
	@RequestMapping(value = { "/noticeBoardList", "/noticeList" }, method = RequestMethod.GET)
	public String noticeBoardList(Model model,
			@RequestParam(value = "pageNum", required = false, defaultValue = "1") int pageNum,
			@RequestParam(value = "category", required = false, defaultValue = "null") String category,
			@RequestParam(value = "keyword", required = false, defaultValue = "null") String keyword) {

		Map<String, Object> modelMap = increpasTourService.noticeBoardList(pageNum, category, keyword);
		model.addAllAttributes(modelMap);
		return "board/noticeBoard";
	}

	// 해외 패키지 자세히 보기
	@RequestMapping(value = "overSeaPackageDetail", method = RequestMethod.GET)
	public String overSeaPackageDetail(Model model,
			@RequestParam(value = "package_tour_idx", required = false) int package_tour_idx) {
		Package_tour_VO packageDetail = increpasTourService.overSeaPackageDetail(package_tour_idx);
		model.addAttribute("packageDetail", packageDetail);
		return "oversea/overSeaPackageDetail";
	}

	// 공지사항 작성
	@RequestMapping(value = "insertNotice", method = RequestMethod.POST)
	public String insertNotice(HttpServletRequest request, String n_board_title, String n_board_contents,
			String n_board_writer, @RequestParam(value = "n_board_file", required = false) MultipartFile multipartFile)
			throws Exception {

		// 현재 날짜를 YYYY-MM-DD HH:MM:SS 형식으로 불러와서 변수에 담아줌
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.KOREA);
		Date currentTime = new Date();
		String mTime = mSimpleDateFormat.format(currentTime);

		// vo 생성
		NoticeBoardVO noticeBoardVO = new NoticeBoardVO();

		// 작성자가 빈 값이면 관리자를 기본 값 설정
		if (n_board_writer == null || n_board_writer == "" || n_board_writer == " ") {
			n_board_writer = "관리자";
		}

		noticeBoardVO.setN_board_title(n_board_title);
		noticeBoardVO.setN_board_writer(n_board_writer);
		noticeBoardVO.setN_board_contents(n_board_contents);

		// 파일이 있으면
		if (!multipartFile.isEmpty()) {
			String filePath = request.getServletContext().getRealPath(DEFAULT_PATH);
			System.out.println(filePath);
			UUID uid = UUID.randomUUID();

			// 파일 이름은 위에서 선언한 현재 시간 변수 + 랜덤 + 원래 이름으로 저장되어짐.
			String saveName = mTime + "_" + uid.toString() + "_" + multipartFile.getOriginalFilename();
			File file = new File(filePath, saveName);
			multipartFile.transferTo(file);
			noticeBoardVO.setN_board_file(saveName);
		}

		increpasTourService.insertNoticeBoard(noticeBoardVO);
		return "redirect:/noticeBoardList";
	}

	// 공지사항 게시글 삭제
	@RequestMapping(value = "deleteNotice", method = RequestMethod.GET)
	public String deleteNotice(int n_board_idx) {
		// System.out.println("삭제 메소드 idx = " + n_board_idx);
		increpasTourService.deleteNoticeBoard(n_board_idx);
		return "redirect:/noticeBoardList";
	}

	// 공지사항 자세히 보기
	@RequestMapping(value = "noticeBoardDetail")
	public String noticeBoardDetail(Model model, @RequestParam(value = "n_board_idx", required = false) int n_board_idx)
			throws Exception {
		NoticeBoardVO noticeBoardDetail = increpasTourService.noticeBoardDetail(n_board_idx);
		model.addAttribute("noticeBoardDetail", noticeBoardDetail);

		if (noticeBoardDetail.getN_board_file() != null) {
			model.addAttribute("file", URLEncoder.encode(noticeBoardDetail.getN_board_file(), "utf-8"));
		}

		return "board/noticeBoardDetail";
	}

	// 공지사항 수정 form
	@RequestMapping(value = "noticeBoardUpdateForm")
	public String noticeBoardUpdateForm(Model model,
			@RequestParam(value = "n_board_idx", required = false) int n_board_idx) throws Exception {
		// 자세히 보기 복붙 하였음.
		NoticeBoardVO noticeBoardDetail = increpasTourService.noticeBoardDetail(n_board_idx);
		model.addAttribute("noticeBoardDetail", noticeBoardDetail);

		if (noticeBoardDetail.getN_board_file() != null) {
			model.addAttribute("file", URLEncoder.encode(noticeBoardDetail.getN_board_file(), "utf-8"));
		}
		return "board/noticeBoardUpdateForm";
	}

	// 공지사항 수정
	@RequestMapping(value = "updateNoticeBoard", method = RequestMethod.POST)
	public String updateNoticeBoard(HttpServletRequest request, String n_board_title, int n_board_idx,
			String n_board_contents,
			@RequestParam(value = "n_board_file", required = false) MultipartFile multipartFile) throws Exception {
//		System.out.println("n_board_title " + n_board_title);
//		System.out.println("n_board_contents " + n_board_contents);
		// 현재 날짜를 YYYY-MM-DD HH:MM:SS 형식으로 불러와서 변수에 담아줌
		// insert에서 약간 변형
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.KOREA);
		Date currentTime = new Date();
		String mTime = mSimpleDateFormat.format(currentTime);
		NoticeBoardVO noticeBoardVO = null;

		// vo 생성
//		NoticeBoardVO noticeBoardVO = new NoticeBoardVO();

//		noticeBoardVO.setN_board_title(n_board_title);
//		noticeBoardVO.setN_board_contents(n_board_contents);

		// 파일이 있으면
		if (!multipartFile.isEmpty()) {
			String filePath = request.getServletContext().getRealPath(DEFAULT_PATH);
			System.out.println(filePath);
			UUID uid = UUID.randomUUID();

			// 파일 이름은 위에서 선언한 현재 시간 변수 + 랜덤 + 원래 이름으로 저장되어짐.
			String saveName = mTime + "_" + uid.toString() + "_" + multipartFile.getOriginalFilename();
			File file = new File(filePath, saveName);
			multipartFile.transferTo(file);
			// noticeBoardVO.setN_board_file(saveName);
			noticeBoardVO = new NoticeBoardVO(n_board_idx, n_board_title, n_board_contents, saveName);
			increpasTourService.updateNoticeBoard(noticeBoardVO);
		} else {
			// 파일이 없을 경우 파일을 제외하고 수정
			noticeBoardVO = new NoticeBoardVO(n_board_idx, n_board_title, n_board_contents);
			increpasTourService.updateNoticeBoard(noticeBoardVO);
		}

		return "redirect:/noticeBoardList";
	}

	// 공지사항에 있는 파일을 다운로드
	@RequestMapping("fileDownload")
	public void download(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String fileName = request.getParameter("fileName");
		String filePath = request.getServletContext().getRealPath(DEFAULT_PATH);

		File file = new File(filePath, fileName);
		response.setContentType("application/download; charset=UTF-8");
		response.setContentLength((int) file.length());

		fileName = URLEncoder.encode(file.getName(), "UTF-8");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\";");
		response.setHeader("Content-Transfer-Encoding", "binary");

		OutputStream out = response.getOutputStream();
		FileInputStream fis = null;
		fis = new FileInputStream(file);
		FileCopyUtils.copy(fis, out);

		if (fis != null) {
			fis.close();
		}
		out.flush();
	}

	// 패키지 업로드
	@RequestMapping(value = "insertPackageList", method = RequestMethod.POST)
	public String insertPackageList(HttpServletRequest request, String package_tour_name,
			String package_tour_start_date, String package_tour_end_date, String package_tour_start,
			String package_tour_natname, String package_tour_waypoint, String package_tour_arrive,
			String package_tour_class, String package_tour_hotel_class, String package_tour_agency,
			String package_tour_theme, int package_tour_price, String package_tour_status, String package_tour_free,
			String package_tour_manager, String package_tour_contents, String package_tour_shopping,
			@RequestParam(value = "package_tour_image", required = false) MultipartFile multipartFile,
			@RequestParam(value = "package_tour_thumbnail", required = false) MultipartFile multipartFile2) {

		System.out.println(package_tour_start_date + " " + package_tour_end_date);
		Package_tour_VO packageTourVO = new Package_tour_VO();

		// 현재 날짜를 변수로 선언
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.KOREA);
		Date currentTime = new Date();
		String mTime = mSimpleDateFormat.format(currentTime);

//		String strStartDate = package_tour_start_date.replaceAll("-", "");
//		String strEndDate = package_tour_end_date.replaceAll("-", "");

		// 날짜 계산식 sdf를 선언 후 시간을 가져와 뺀 후
		// 24시간 * 60분 * 60초 * 1000분의 1을 곱한 값을 나누기로 계산
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date beginDate;
		try {
			beginDate = formatter.parse(package_tour_start_date);
			Date endDate = formatter.parse(package_tour_end_date);

			long diff = endDate.getTime() - beginDate.getTime();
			long diffDays = diff / (24 * 60 * 60 * 1000);

			System.out.println("날짜차이 : " + diffDays + "일");
			packageTourVO.setPackage_tour_total(diffDays);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("insertPackageList 날짜 계산 부분 try catch 에러 발생");
		}

//		int startDate = Integer.parseInt(strStartDate.substring(4, 8));
//		int endDate = Integer.parseInt(strEndDate.substring(4, 8));
//		System.out.println("startDate : "+ startDate);
//		System.out.println("endDate : "+ endDate);
//		int total = endDate - startDate;

		packageTourVO.setPackage_tour_name(package_tour_name);
		packageTourVO.setPackage_tour_start_date(package_tour_start_date);
		packageTourVO.setPackage_tour_end_date(package_tour_end_date);
		packageTourVO.setPackage_tour_start(package_tour_start);
		packageTourVO.setPackage_tour_natname(package_tour_natname);
		packageTourVO.setPackage_tour_waypoint(package_tour_waypoint);
		packageTourVO.setPackage_tour_arrive(package_tour_arrive);
		packageTourVO.setPackage_tour_theme(package_tour_theme);
		packageTourVO.setPackage_tour_price(package_tour_price);
		packageTourVO.setPackage_tour_status(package_tour_status);
		packageTourVO.setPackage_tour_free(package_tour_free);
		packageTourVO.setPackage_tour_manager(package_tour_manager);
		packageTourVO.setPackage_tour_contents(package_tour_contents);
		packageTourVO.setPackage_tour_agency(package_tour_agency);
		packageTourVO.setPackage_tour_hotel_class(package_tour_hotel_class);
		packageTourVO.setPackage_tour_class(package_tour_class);
		packageTourVO.setPackage_tour_shopping(package_tour_shopping);

		if (!multipartFile.isEmpty() && !multipartFile2.isEmpty()) {
			String filePath = request.getServletContext().getRealPath(IMAGE_PATH);
			System.out.println(filePath);
			UUID uid = UUID.randomUUID();

			// 파일 이름은 위에서 선언한 현재 시간 변수 + 랜덤 + 원래 이름으로 저장되어짐.
			String saveName = mTime + "_" + uid.toString() + "_" + multipartFile.getOriginalFilename();
			String saveName2 = mTime + "_" + uid.toString() + "_" + multipartFile2.getOriginalFilename();
			File file = new File(filePath, saveName);
			File file2 = new File(filePath, saveName2);
			try {
				multipartFile.transferTo(file);
				multipartFile2.transferTo(file2);
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			packageTourVO.setPackage_tour_thumbnail(saveName);
			packageTourVO.setPackage_tour_image(saveName2);
			// noticeBoardVO.setN_board_file(saveName);
		}

		increpasTourService.insertPackageList(packageTourVO);
		return "redirect:packageList";
	}

	@RequestMapping("deletePackageList")
	public String deletePackageList(int package_tour_idx) {
		increpasTourService.deletePackageList(package_tour_idx);
		return "redirect:packageList";
	}

	@RequestMapping("updateFormPackage")
	public String updateFormPackage(Model model,
			@RequestParam(value = "package_tour_idx", required = false) int package_tour_idx) {
		Package_tour_VO updatePackage = increpasTourService.overSeaPackageDetail(package_tour_idx);
		model.addAttribute("updatePackage", updatePackage);
		return "oversea/updateFormPackage";
	}

	@RequestMapping(value = "updatePackageList", method = RequestMethod.POST)
	public String updatePackageList(HttpServletRequest request, int package_tour_idx, String package_tour_name,
			String package_tour_start_date, String package_tour_end_date, String package_tour_start,
			String package_tour_natname, String package_tour_waypoint, String package_tour_arrive,
			String package_tour_class, String package_tour_hotel_class, String package_tour_agency,
			String package_tour_theme, int package_tour_price, String package_tour_status, String package_tour_free,
			String package_tour_manager, String package_tour_contents, String package_tour_shopping,
			@RequestParam(value = "package_tour_image", required = false) MultipartFile multipartFile,
			@RequestParam(value = "package_tour_thumbnail", required = false) MultipartFile multipartFile2)
			throws Exception {
		Package_tour_VO packageTourVO = null;

		// 현재 날짜를 변수로 선언
		SimpleDateFormat mSimpleDateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.KOREA);
		Date currentTime = new Date();
		String mTime = mSimpleDateFormat.format(currentTime);

//		String strStartDate = package_tour_start_date.replaceAll("-", "");
//		String strEndDate = package_tour_end_date.replaceAll("-", "");

		// 날짜 계산식 sdf를 선언 후 시간을 가져와 뺀 후
		// 24시간 * 60분 * 60초 * 1000분의 1을 곱한 값을 나누기로 계산
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date beginDate;
		beginDate = formatter.parse(package_tour_start_date);
		Date endDate = formatter.parse(package_tour_end_date);

		long diff = endDate.getTime() - beginDate.getTime();
		long diffDays = diff / (24 * 60 * 60 * 1000);

		System.out.println("날짜차이 : " + diffDays + "일");

//		int startDate = Integer.parseInt(strStartDate.substring(4, 8));
//		int endDate = Integer.parseInt(strEndDate.substring(4, 8));
//		System.out.println("startDate : "+ startDate);
//		System.out.println("endDate : "+ endDate);
//		int total = endDate - startDate;

		if (!multipartFile.isEmpty() && !multipartFile2.isEmpty()) {
			String filePath = request.getServletContext().getRealPath(IMAGE_PATH);
			System.out.println(filePath);
			UUID uid = UUID.randomUUID();

			// 파일 이름은 위에서 선언한 현재 시간 변수 + 랜덤 + 원래 이름으로 저장되어짐.
			String saveName = mTime + "_" + uid.toString() + "_" + multipartFile.getOriginalFilename();
			String saveName2 = mTime + "_" + uid.toString() + "_" + multipartFile2.getOriginalFilename();
			File file = new File(filePath, saveName);
			File file2 = new File(filePath, saveName2);
			multipartFile.transferTo(file);
			multipartFile2.transferTo(file2);

			packageTourVO = new Package_tour_VO(package_tour_idx, diffDays, package_tour_price, package_tour_name,
					package_tour_start_date, package_tour_end_date, saveName, package_tour_contents, package_tour_start,
					package_tour_arrive, package_tour_natname, package_tour_class, package_tour_hotel_class,
					package_tour_agency, package_tour_theme, package_tour_status, package_tour_free,
					package_tour_shopping, package_tour_manager, package_tour_waypoint, saveName2);
			increpasTourService.updatePackageList(packageTourVO);
			System.out.println("파일 추가 수정이 완료되었습니다.");
		} else {
			System.out.println("파일을 추가 하지 않아서 수정에 실패했습니다.");
		}
		return "redirect:packageList";
	}
}