package com.tour.increpas.service;

import java.util.List;
import java.util.Map;

import com.tour.increpas.vo.NoticeBoardVO;
import com.tour.increpas.vo.Package_do_tour_VO;
import com.tour.increpas.vo.Package_tour_VO;

public interface IncrepasTourService {
	public abstract Map<String, Object> packageList(String nations, String category, String keyword);
	public abstract Package_tour_VO overSeaPackageDetail(int package_tour_idx);
	public abstract List<Package_do_tour_VO> package_do_List();
	public abstract Package_do_tour_VO getBoard(int package_do_tour_idx);
	public abstract Map<String, Object> noticeBoardList(int pageNum,  String category, String keyword);
	public abstract int getNoticeBoardCount(String category, String keyword);
	public abstract void insertNoticeBoard(NoticeBoardVO noticeBoardVO);
	// 맵 관련
	public abstract List<Package_do_tour_VO> map_List();
	public abstract void deleteNoticeBoard(int n_board_idx);
	public abstract NoticeBoardVO noticeBoardDetail(int n_board_idx);
	public abstract void updateNoticeBoard(NoticeBoardVO noticeBoardVO);
	public abstract void insertPackageList(Package_tour_VO package_tour_vo);
	public abstract void deletePackageList(int package_tour_idx);
	public abstract void updatePackageList(Package_tour_VO package_tour_VO);
	
}